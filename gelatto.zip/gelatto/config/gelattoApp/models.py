from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import datetime

# --- MÓDULO 1: ESTANDARIZACIÓN ---

class Ingrediente(models.Model):
    nombre = models.CharField(max_length=100, unique=True)
    unidad_medida = models.CharField(max_length=50)
    costo_unitario = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.nombre} ({self.unidad_medida})"

class Receta(models.Model):
    CATEGORIA_CHOICES = [
        ('HELADO', 'Helados'),
        ('PASTEL', 'Pasteles'),
        ('CAFE', 'Cafés'),
        ('OTRO', 'Otro'),
    ]
    ESTADO_CHOICES = [
        ('ACTIVO', 'Activo'),
        ('INACTIVO', 'Inactivo'),
    ]

    nombre = models.CharField(max_length=200)
    categoria = models.CharField(max_length=50, choices=CATEGORIA_CHOICES, default='OTRO')
    instrucciones = models.TextField()
    porciones = models.IntegerField(default=1, verbose_name="Porciones Estándar")
    estado = models.CharField(max_length=50, choices=ESTADO_CHOICES, default='ACTIVO')
    creado_por = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='recetas_creadas')
    ingredientes = models.ManyToManyField(Ingrediente, through='RecetaIngrediente')
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nombre

    # Cálculo del costo unitario de la receta base
    def get_costo_unitario(self):
        total = 0
        for relacion in self.recetaingrediente_set.all():
            total += relacion.cantidad * relacion.ingrediente.costo_unitario
        return total

class RecetaIngrediente(models.Model):
    receta = models.ForeignKey(Receta, on_delete=models.CASCADE)
    ingrediente = models.ForeignKey(Ingrediente, on_delete=models.CASCADE)
    cantidad = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.receta.nombre} - {self.ingrediente.nombre}"
    
    class Meta:
        unique_together = ('receta', 'ingrediente')

# --- MÓDULO 2: PLANIFICACIÓN DE PRODUCCIÓN ---

class PlanProduccion(models.Model):
    ESTADO_PLAN = [
        ('PENDIENTE', 'Pendiente'),
        ('EN_PROCESO', 'En Proceso'),
        ('COMPLETADO', 'Completado'),
        ('CANCELADO', 'Cancelado'),
    ]

    receta = models.ForeignKey(Receta, on_delete=models.PROTECT, verbose_name="Receta a Producir")
    fecha_planificada = models.DateField(default=datetime.date.today, verbose_name="Fecha de Producción")
    cantidad_a_producir = models.DecimalField(max_digits=10, decimal_places=2, help_text="Cantidad objetivo")
    estado = models.CharField(max_length=20, choices=ESTADO_PLAN, default='PENDIENTE')
    responsable = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, verbose_name="Responsable")
    notas = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Plan: {self.receta.nombre} para {self.fecha_planificada}"
    
    # Cálculo del costo total de la producción (Costo Unitario * Cantidad a Producir)
    def get_costo_total_produccion(self):
        costo_receta = self.receta.get_costo_unitario()
        if costo_receta and self.cantidad_a_producir:
            return costo_receta * self.cantidad_a_producir
        return 0

    class Meta:
        verbose_name = "Plan de Producción"
        verbose_name_plural = "Planes de Producción"
        ordering = ['fecha_planificada']