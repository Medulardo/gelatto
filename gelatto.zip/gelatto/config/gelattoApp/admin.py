from django.contrib import admin
from .models import Ingrediente, Receta, RecetaIngrediente

# Un 'inline' permite editar los ingredientes directamente
# desde la página de la receta en el admin
class RecetaIngredienteInline(admin.TabularInline):
    model = RecetaIngrediente
    extra = 1 # Muestra 1 campo vacío para añadir

@admin.register(Receta)
class RecetaAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'categoria', 'estado', 'creado_por')
    list_filter = ('categoria', 'estado')
    search_fields = ('nombre',)
    inlines = [RecetaIngredienteInline]

@admin.register(Ingrediente)
class IngredienteAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'unidad_medida', 'costo_unitario')
    search_fields = ('nombre',)

# Opcional: registrar el modelo intermedio si quieres verlo por separado
# admin.site.register(RecetaIngrediente)