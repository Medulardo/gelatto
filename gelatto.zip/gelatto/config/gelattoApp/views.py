from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
# Importamos forms y modelos
from .forms import CustomLoginForm, RecetaForm, IngredienteForm, IngredienteFormSet, PlanProduccionForm, PlanStatusUpdateForm
from .models import Receta, Ingrediente, PlanProduccion
# Importamos los nuevos decoradores
from .decorators import puede_editar_recetas, puede_gestionar_produccion, staff_produccion
import datetime

# --- Helpers de Rol (Nombres Exactos) ---
def es_jefa_cocina(user):
    return user.groups.filter(name='JefaDeCocina').exists()

def es_jefa_produccion(user):
    return user.groups.filter(name='JefaDeProduccion').exists()

def es_admin(user):
    return user.is_superuser or user.groups.filter(name='admin').exists()

# --- Auth ---
def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('home')
    else:
        form = CustomLoginForm()
    return render(request, 'login.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home_view(request):
    hoy = datetime.date.today()
    planes_hoy = PlanProduccion.objects.filter(fecha_planificada=hoy).order_by('estado')
    
    context = {
        'planes_hoy': planes_hoy,
        'es_admin': es_admin(request.user),
        'es_jefa_cocina': es_jefa_cocina(request.user),
        'es_jefa_produccion': es_jefa_produccion(request.user)
    }
    return render(request, 'home.html', context)

# ==========================================
#  CRUD 1: RECETAS
#  - Crear/Editar/Borrar: Admin, JefaDeCocina
#  - Ver: Todos (incluida JefaDeProduccion solo lectura)
# ==========================================

@login_required
def receta_list(request):
    categoria = request.GET.get('categoria')
    recetas = Receta.objects.filter(estado='ACTIVO')
    if categoria and categoria != 'TODAS':
        recetas = recetas.filter(categoria=categoria)
    
    # Variable para el template: ¿Quién ve el botón de crear?
    permiso_edicion = es_admin(request.user) or es_jefa_cocina(request.user)
    
    return render(request, 'gestion_recetas/receta_list.html', {
        'recetas': recetas, 
        'categorias': Receta.CATEGORIA_CHOICES,
        'categoria_actual': categoria or 'TODAS',
        'puede_editar': permiso_edicion
    })

@login_required
def receta_detail(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    ingredientes = receta.recetaingrediente_set.all()
    
    # Variable para el template: ¿Quién ve los botones editar/borrar?
    permiso_edicion = es_admin(request.user) or es_jefa_cocina(request.user)

    return render(request, 'gestion_recetas/receta_detail.html', {
        'receta': receta, 
        'ingredientes': ingredientes,
        'costo_unitario': receta.get_costo_unitario(),
        'puede_editar': permiso_edicion
    })

@puede_editar_recetas
def receta_create(request):
    if request.method == 'POST':
        form = RecetaForm(request.POST)
        formset = IngredienteFormSet(request.POST, prefix='ingredientes')
        if form.is_valid() and formset.is_valid():
            receta = form.save(commit=False)
            receta.creado_por = request.user
            receta.save()
            formset.instance = receta
            formset.save()
            return redirect('receta_detail', pk=receta.pk)
    else:
        form = RecetaForm()
        formset = IngredienteFormSet(prefix='ingredientes')
    return render(request, 'gestion_recetas/receta_form.html', {'form': form, 'formset': formset, 'es_nuevo': True})

@puede_editar_recetas
def receta_update(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    if request.method == 'POST':
        form = RecetaForm(request.POST, instance=receta)
        formset = IngredienteFormSet(request.POST, instance=receta, prefix='ingredientes')
        if form.is_valid() and formset.is_valid():
            form.save()
            formset.save()
            return redirect('receta_detail', pk=receta.pk)
    else:
        form = RecetaForm(instance=receta)
        formset = IngredienteFormSet(instance=receta, prefix='ingredientes')
    return render(request, 'gestion_recetas/receta_form.html', {'form': form, 'formset': formset, 'receta': receta, 'es_nuevo': False})

@puede_editar_recetas
def receta_delete(request, pk):
    receta = get_object_or_404(Receta, pk=pk)
    if request.method == 'POST':
        receta.estado = 'INACTIVO'
        receta.save()
        return redirect('receta_list')
    return render(request, 'gestion_recetas/receta_confirm_delete.html', {'receta': receta})

# --- INGREDIENTES (Solo Admin y JefaDeCocina) ---

@puede_editar_recetas
def ingrediente_list(request):
    ingredientes = Ingrediente.objects.all().order_by('nombre')
    return render(request, 'gestion_ingredientes/ingrediente_list.html', {'ingredientes': ingredientes})

@puede_editar_recetas
def ingrediente_create(request):
    if request.method == 'POST':
        form = IngredienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('ingrediente_list')
    else:
        form = IngredienteForm()
    return render(request, 'gestion_ingredientes/ingrediente_form.html', {'form': form, 'es_nuevo': True})

@puede_editar_recetas
def ingrediente_update(request, pk):
    ingrediente = get_object_or_404(Ingrediente, pk=pk)
    if request.method == 'POST':
        form = IngredienteForm(request.POST, instance=ingrediente)
        if form.is_valid():
            form.save()
            return redirect('ingrediente_list')
    else:
        form = IngredienteForm(instance=ingrediente)
    return render(request, 'gestion_ingredientes/ingrediente_form.html', {'form': form, 'es_nuevo': False})

@puede_editar_recetas
def ingrediente_delete(request, pk):
    ingrediente = get_object_or_404(Ingrediente, pk=pk)
    if request.method == 'POST':
        ingrediente.delete()
        return redirect('ingrediente_list')
    return render(request, 'gestion_ingredientes/ingrediente_confirm_delete.html', {'ingrediente': ingrediente})


# ==========================================
#  CRUD 2: PRODUCCIÓN
#  - Admin / JefaDeProduccion: FULL ACCESO
#  - JefaDeCocina: Ver + Solo editar ESTADO
# ==========================================

@staff_produccion
def plan_list(request):
    planes = PlanProduccion.objects.all().order_by('fecha_planificada')
    
    # Permiso para CREAR y BORRAR (Solo Admin y JefaDeProduccion)
    permiso_full = es_admin(request.user) or es_jefa_produccion(request.user)
    
    return render(request, 'gestion_produccion/plan_list.html', {
        'planes': planes,
        'permiso_full': permiso_full
    })

@puede_gestionar_produccion
def plan_create(request):
    if request.method == 'POST':
        form = PlanProduccionForm(request.POST)
        if form.is_valid():
            plan = form.save(commit=False)
            plan.responsable = request.user
            plan.save()
            return redirect('plan_list')
    else:
        manana = datetime.date.today() + datetime.timedelta(days=1)
        form = PlanProduccionForm(initial={'fecha_planificada': manana})
    return render(request, 'gestion_produccion/plan_form.html', {'form': form, 'es_nuevo': True, 'titulo': 'Nueva Planificación'})

@staff_produccion
def plan_update(request, pk):
    plan = get_object_or_404(PlanProduccion, pk=pk)
    
    # LÓGICA CLAVE: ¿Es JefaDeCocina (restringida)?
    es_restringido = es_jefa_cocina(request.user) and not (es_admin(request.user) or es_jefa_produccion(request.user))
    
    if es_restringido:
        FormClass = PlanStatusUpdateForm
        titulo = "Actualizar Estado"
    else:
        FormClass = PlanProduccionForm
        titulo = "Editar Planificación"

    if request.method == 'POST':
        form = FormClass(request.POST, instance=plan)
        if form.is_valid():
            form.save()
            return redirect('plan_list')
    else:
        form = FormClass(instance=plan)
    
    return render(request, 'gestion_produccion/plan_form.html', {
        'form': form, 
        'es_nuevo': False, 
        'titulo': titulo,
        'solo_estado': es_restringido, # Flag para el template
        'plan': plan
    })

@puede_gestionar_produccion
def plan_delete(request, pk):
    plan = get_object_or_404(PlanProduccion, pk=pk)
    if request.method == 'POST':
        plan.delete()
        return redirect('plan_list')
    return render(request, 'gestion_produccion/plan_confirm_delete.html', {'plan': plan})