from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('', views.home_view, name='home'),
    
    # CRUD 1: Recetas (Estandarización)
    path('recetas/', views.receta_list, name='receta_list'),
    path('recetas/nueva/', views.receta_create, name='receta_create'),
    path('recetas/<int:pk>/', views.receta_detail, name='receta_detail'),
    path('recetas/<int:pk>/editar/', views.receta_update, name='receta_update'),
    path('recetas/<int:pk>/eliminar/', views.receta_delete, name='receta_delete'),
    
    # CRUD: Ingredientes (Rutas corregidas)
    path('ingredientes/', views.ingrediente_list, name='ingrediente_list'),
    path('ingredientes/nuevo/', views.ingrediente_create, name='ingrediente_create'),
    path('ingredientes/<int:pk>/editar/', views.ingrediente_update, name='ingrediente_update'),
    path('ingredientes/<int:pk>/eliminar/', views.ingrediente_delete, name='ingrediente_delete'),
    
    # CRUD 2: Planificación de Producción
    path('planificacion/', views.plan_list, name='plan_list'),
    path('planificacion/nueva/', views.plan_create, name='plan_create'),
    path('planificacion/<int:pk>/editar/', views.plan_update, name='plan_update'),
    path('planificacion/<int:pk>/eliminar/', views.plan_delete, name='plan_delete'),
]