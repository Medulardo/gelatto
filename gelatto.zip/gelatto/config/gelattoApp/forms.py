from django import forms
from .models import Receta, Ingrediente, RecetaIngrediente, PlanProduccion
from django.contrib.auth.forms import AuthenticationForm
from django.forms import inlineformset_factory

class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Usuario'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Contraseña'}))

# --- Recetas ---
class RecetaForm(forms.ModelForm):
    class Meta:
        model = Receta
        fields = ['nombre', 'categoria', 'instrucciones', 'estado']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'categoria': forms.Select(attrs={'class': 'form-select'}),
            'instrucciones': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
        }

class IngredienteForm(forms.ModelForm):
    class Meta:
        model = Ingrediente
        fields = ['nombre', 'unidad_medida', 'costo_unitario']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'unidad_medida': forms.TextInput(attrs={'class': 'form-control'}),
            'costo_unitario': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class RecetaIngredienteForm(forms.ModelForm):
    class Meta:
        model = RecetaIngrediente
        fields = ['ingrediente', 'cantidad']
        widgets = {
            'ingrediente': forms.Select(attrs={'class': 'form-select'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Cant.'}),
        }

IngredienteFormSet = inlineformset_factory(
    Receta, RecetaIngrediente, form=RecetaIngredienteForm,
    extra=1, can_delete=True
)

# --- Producción ---

# 1. Formulario Completo (Admin y JefaDeProduccion)
class PlanProduccionForm(forms.ModelForm):
    class Meta:
        model = PlanProduccion
        fields = ['fecha_planificada', 'receta', 'cantidad_a_producir', 'estado', 'notas']
        widgets = {
            'fecha_planificada': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'receta': forms.Select(attrs={'class': 'form-select'}),
            'cantidad_a_producir': forms.NumberInput(attrs={'class': 'form-control'}),
            'estado': forms.Select(attrs={'class': 'form-select'}),
            'notas': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['receta'].queryset = Receta.objects.filter(estado='ACTIVO')

# 2. Formulario Restringido (Solo para JefaDeCocina - Solo Estado)
class PlanStatusUpdateForm(forms.ModelForm):
    class Meta:
        model = PlanProduccion
        fields = ['estado'] # SOLO ESTADO
        widgets = {
            'estado': forms.Select(attrs={'class': 'form-select form-select-lg'}),
        }