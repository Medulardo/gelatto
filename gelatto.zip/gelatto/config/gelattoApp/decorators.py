from django.contrib.auth.decorators import user_passes_test
from django.core.exceptions import PermissionDenied

def group_required(*group_names):
    """Verifica si el usuario es superuser O pertenece a uno de los grupos."""
    def in_groups(user):
        if user.is_authenticated:
            if user.is_superuser:
                return True
            if bool(user.groups.filter(name__in=group_names)):
                return True
        return False
    return user_passes_test(in_groups, login_url='login')

# --- Decoradores de Acceso ---

# Permite Crear/Editar Recetas (Admin + JefaDeCocina)
def puede_editar_recetas(view_func):
    return group_required('admin', 'JefaDeCocina')(view_func)

# Permite Crear/Eliminar Planes de Producción (Admin + JefaDeProduccion)
def puede_gestionar_produccion(view_func):
    return group_required('admin', 'JefaDeProduccion')(view_func)

# Acceso general a vistas de producción (Admin + JefaDeProduccion + JefaDeCocina)
def staff_produccion(view_func):
    return group_required('admin', 'JefaDeProduccion', 'JefaDeCocina')(view_func)